package com.himansim.hcharityapi.services;

import com.himansim.hcharityapi.domain.entity.User;
import com.himansim.hcharityapi.dto.request.RegisterUserDTO;
import com.himansim.hcharityapi.dto.request.UserLoginDto;
import com.himansim.hcharityapi.dto.response.RegisterUserResponseDTO;

public interface AuthService {

    RegisterUserResponseDTO registerUser(RegisterUserDTO registerUserDTO);

    User register(String email, String password);

    UserLoginDto login(String email, String password);
    
}
