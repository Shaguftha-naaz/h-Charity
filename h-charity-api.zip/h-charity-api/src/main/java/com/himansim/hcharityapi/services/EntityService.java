package com.himansim.hcharityapi.services;

import java.util.List;

import org.springframework.security.core.Authentication;

import com.himansim.hcharityapi.domain.entity.Party;
import com.himansim.hcharityapi.dto.request.PartyDto;

public interface EntityService {
 List<Party> getEntities(Authentication authentication);

    Party addEntity(PartyDto partyDto);
}
