package com.himansim.hcharityapi.domain.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "party")
@NoArgsConstructor
public class Party {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Long phoneNo;
    private String billingAddress;
    private String shippingAddress;
    private String emailId;
    private String gstType;
    private String gstNumber;
    private String gstState;
    private String openingBalance;
    private String asOfDate;
}
