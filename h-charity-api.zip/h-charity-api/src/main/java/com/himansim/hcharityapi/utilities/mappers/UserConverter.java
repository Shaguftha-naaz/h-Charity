package com.himansim.hcharityapi.utilities.mappers;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.himansim.hcharityapi.domain.entity.User;
import com.himansim.hcharityapi.dto.request.RegisterUserDTO;
import com.himansim.hcharityapi.dto.response.RegisterUserResponseDTO;

@Component
public class UserConverter {
    private final ModelMapper modelMapper;

    public UserConverter(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public User convertRegisterDTOToUser(RegisterUserDTO userDTO) {
        return modelMapper.map(userDTO, User.class);
    }

    public RegisterUserResponseDTO convertUserToRegisterResponseDTO(User userEntity) {
        return modelMapper.map(userEntity, RegisterUserResponseDTO.class);
    }
}
