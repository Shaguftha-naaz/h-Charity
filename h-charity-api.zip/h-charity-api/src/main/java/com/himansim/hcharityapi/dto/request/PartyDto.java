package com.himansim.hcharityapi.dto.request;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PartyDto {
    private Long id;
    private String name;
    private Long phoneNo;
    private String billingAddress;
    private String shippingAddress;
    private String emailId;
    private String gstType;
    private String gstNumber;
    private String gstState;
    private String openingBalance;
    private String asOfDate;
}
