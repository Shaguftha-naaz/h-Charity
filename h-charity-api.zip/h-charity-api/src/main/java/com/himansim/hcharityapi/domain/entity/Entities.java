package com.himansim.hcharityapi.domain.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.List;

import jakarta.persistence.Entity;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "entity")
@NoArgsConstructor
public class Entities {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String type;
    private String president;
    private String poc;
    private String description;
    private Boolean isVerified;
    private Boolean hasInternet;
    private List<String> photos;
    private String mobile;
    private String office;
    private Address address;
}
