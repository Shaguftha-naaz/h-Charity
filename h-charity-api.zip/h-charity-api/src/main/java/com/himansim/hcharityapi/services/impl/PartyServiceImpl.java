package com.himansim.hcharityapi.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.himansim.hcharityapi.domain.entity.Party;
import com.himansim.hcharityapi.domain.repo.PartyRepository;
import com.himansim.hcharityapi.dto.request.PartyDto;
import com.himansim.hcharityapi.services.PartyService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class PartyServiceImpl implements PartyService {

    private final PartyRepository partyRepository;

    @Override
    public List<Party> getParties(Authentication authentication) {
        return partyRepository.findAll();
    }

    @Override
    public Party addParty(PartyDto partyDto) {
        Party party = new Party();
        party.setName(partyDto.getName());
        party.setPhoneNo(partyDto.getPhoneNo());
        party.setBillingAddress(partyDto.getBillingAddress());
        party.setShippingAddress(partyDto.getShippingAddress());
        party.setEmailId(partyDto.getEmailId());
        party.setGstType(partyDto.getGstType());
        party.setGstNumber(partyDto.getGstNumber());        
        party.setGstState(partyDto.getGstState());
        party.setOpeningBalance(partyDto.getOpeningBalance());        
        party.setAsOfDate(partyDto.getAsOfDate());

        return partyRepository.save(party);
    }

    @Override
    public Party updateParty(PartyDto partyDto) {
        Optional<Party> existingParty = partyRepository.findById(partyDto.getId());
        if (existingParty.isEmpty()) throw new IllegalArgumentException("Invalid party ID");
        Party updatedParty = existingParty.get();

        updatedParty.setName(partyDto.getName());
        updatedParty.setPhoneNo(partyDto.getPhoneNo());
        updatedParty.setBillingAddress(partyDto.getBillingAddress());
        updatedParty.setShippingAddress(partyDto.getShippingAddress());
        updatedParty.setEmailId(partyDto.getEmailId());
        updatedParty.setGstType(partyDto.getGstType());
        updatedParty.setGstNumber(partyDto.getGstNumber());        
        updatedParty.setGstState(partyDto.getGstState());
        updatedParty.setOpeningBalance(partyDto.getOpeningBalance());        
        updatedParty.setAsOfDate(partyDto.getAsOfDate());

        return partyRepository.save(updatedParty);
    }

    @Override
    public void deleteParty(Long partyId) {
         partyRepository.deleteById(partyId);
    }
}
