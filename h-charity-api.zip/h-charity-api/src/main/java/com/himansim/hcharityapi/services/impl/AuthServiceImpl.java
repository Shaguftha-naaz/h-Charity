package com.himansim.hcharityapi.services.impl;

import java.util.HashSet;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.himansim.hcharityapi.domain.entity.User;
import com.himansim.hcharityapi.domain.entity.UserRole;
import com.himansim.hcharityapi.domain.repo.AuthRepo;
import com.himansim.hcharityapi.domain.repo.UserRepository;
import com.himansim.hcharityapi.domain.repo.UserRoleRepository;
import com.himansim.hcharityapi.dto.request.RegisterUserDTO;
import com.himansim.hcharityapi.dto.request.UserLoginDto;
import com.himansim.hcharityapi.dto.response.RegisterUserResponseDTO;
import com.himansim.hcharityapi.services.AuthService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AuthServiceImpl implements AuthService {

    private AuthRepo authRepo;
    private ModelMapper mapper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private TokenService tokenService;

    public AuthServiceImpl(ModelMapper mapper, AuthRepo authRepo) {
        this.authRepo = authRepo;
        this.mapper = mapper;
    }

    @Override
    public RegisterUserResponseDTO registerUser(RegisterUserDTO registerUserDTO) {
        User user = mapper.map(registerUserDTO, User.class);
        return mapper.map(authRepo.saveAndFlush(user), RegisterUserResponseDTO.class);
    }

  public User register(String email, String password) {
        String encodedPassword = passwordEncoder.encode(password);

        UserRole userRole = userRoleRepository.findByAuthority("USER").get();
        Set<UserRole> authorities = new HashSet<>();

        authorities.add(userRole);

        return userRepository.save(new User(email, encodedPassword, authorities));
    }

    public UserLoginDto login(String email, String password) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, password)
            );

            String token = tokenService.generateJwt(auth);

            User user = userRepository.findByEmail(email).orElse(null);
            if (user != null) {
                return new UserLoginDto(user.getId(), user, token);
            } else {
                return new UserLoginDto(null, null, "");
            }

        } catch (AuthenticationException e) {
            return new UserLoginDto(null, null, "");
        }
    }
}
