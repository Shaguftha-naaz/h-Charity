package com.himansim.hcharityapi.services;

import org.springframework.security.core.Authentication;

import com.himansim.hcharityapi.domain.entity.Party;
import com.himansim.hcharityapi.dto.request.PartyDto;

import java.util.List;

public interface PartyService {

    List<Party> getParties(Authentication authentication);

    Party addParty(PartyDto partyDto);

    Party updateParty(PartyDto partyDto);

    void deleteParty(Long partyId);

}
