package com.himansim.hcharityapi.controller;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.himansim.hcharityapi.domain.entity.Party;
import com.himansim.hcharityapi.dto.request.PartyDto;
import com.himansim.hcharityapi.services.PartyService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/party")
public class EntityController {

        private final PartyService partyService;


     @GetMapping("")
    public List<Party> getParties(Authentication authentication) {
            // log.info("UsersController: List users");
        return partyService.getParties(authentication);
    }

    @PostMapping("")
    public Party addParty(@Valid @RequestBody PartyDto partyDto) {
        // if (user.getEmail() == null || user.getEmail().isEmpty() || user.getPassword() == null || user.getPassword().isEmpty()) {
        //     throw new AppException("All fields are required.", HttpStatus.BAD_REQUEST);
        // }

        return partyService.addParty(partyDto);
    } 
}
