package com.himansim.hcharityapi.dto.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RegisterUserDTO {
    private Integer id;
    private String username;    
    private String password;
    private String email;
    private String mobile;
}
